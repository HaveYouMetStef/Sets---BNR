import Cocoa

let myCities: Set = ["Atlanta", "Chicago", "Jacksonville", "New York", "Denver"]
let yourCities: Set = ["Chicago", "Denver", "Jacksonville"]

let disjoint =
myCities.isDisjoint(with: yourCities)

myCities.isStrictSuperset(of: yourCities)




