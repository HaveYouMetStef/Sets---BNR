import Cocoa

//*Objective - 11.1 Creating a set

//var groceryList = Set<String>(["Apples", "Oranges"])

//*Objective - 11.2 Creating a set using array literal syntax
var groceryList: Set = ["Apples", "Oranges"]

//*Objective - 11.3 Adding to a set
groceryList.insert("Kiwi")
groceryList.insert("Pears")

//*Objective - 11.4 Looping through a set
for food in groceryList {
    print(food)
}
//*Objective - 11.5 removing an element from a set
groceryList.remove("Pears")
//*Objective - 11.6 Has Bananas?
let hasBananas = groceryList.contains("Bananas")
//*Objective - 11.7 Combining sets
let friendsGroceryList =
    Set(["Bananas", "Cereal", "Milk", "Oranges"])
let sharedList = groceryList.union(friendsGroceryList)
//*Objective - 11.8 Intersecting sets
let duplicateItems =
groceryList.intersection(friendsGroceryList)
//*Objective - 11.9 Detecting intersections in sets
let disjoint =
groceryList.isDisjoint(with: friendsGroceryList)

//*Objective - 11.10 Playing games
let players = ["Anna", "Vijay", "Jenka"]
let winners = ["Jenka", "Jenka", "Vijay", "Jenka"]
//*Objective - 11.11 Initializing sets using arrays
let playerSet = Set(players)
let winnerSet = Set(winners)
//*Objective - 11.12 subtracting one set from another
playerSet.subtracting(winnerSet)



